import React from 'react'

export default function ScreenLoader() {
    return (
        <div className='loader-container'>
            <span className="loader"></span>
        </div>
    )
}
